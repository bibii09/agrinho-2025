let trator;
let recursos = [];
let obstaculos = [];
let pontuacao = 0;
let vidas = 3;
let estadoJogo = 'inicio'; // pode ser 'inicio', 'jogando', 'fim'

// Variáveis para as imagens (opcional, se você quiser usar imagens)
let imgTrator;
let imgMilho;
let imgVaca;
let imgMeteoro;
let imgFundo;

function preload() {
    // Se você tiver imagens, carregue-as aqui.
    // Exemplo:
    // imgTrator = loadImage('assets/trator.png');
    // imgMilho = loadImage('assets/milho.png');
    // imgVaca = loadImage('assets/vaca.png');
    // imgMeteoro = loadImage('assets/meteoro.png');
    // imgFundo = loadImage('assets/fundo_espacial_rural.png');
}

function setup() {
    createCanvas(800, 600);
    trator = new Trator();
}

function draw() {
    background(0); // Fundo preto para o espaço
    // Se você tiver uma imagem de fundo:
    // image(imgFundo, 0, 0, width, height);

    if (estadoJogo === 'inicio') {
        mostrarTelaInicio();
    } else if (estadoJogo === 'jogando') {
        jogar();
    } else if (estadoJogo === 'fim') {
        mostrarTelaFim();
    }
}

function mostrarTelaInicio() {
    textAlign(CENTER);
    textSize(40);
    fill(255);
    text("Fazendeiro Espacial", width / 2, height / 2 - 50);
    textSize(20);
    text("Pressione ENTER para começar", width / 2, height / 2 + 20);
}

function jogar() {
    // Atualiza e mostra o trator
    trator.mover();
    trator.mostrar();

    // Gera recursos e obstáculos
    if (frameCount % 60 === 0) { // Gera um recurso a cada segundo
        recursos.push(new Recurso());
    }
    if (frameCount % 40 === 0) { // Gera um obstáculo um pouco mais frequentemente
        obstaculos.push(new Obstaculo());
    }

    // Atualiza e mostra recursos
    for (let i = recursos.length - 1; i >= 0; i--) {
        recursos[i].mover();
        recursos[i].mostrar();
        if (recursos[i].colisao(trator)) {
            pontuacao += 10;
            recursos.splice(i, 1); // Remove o recurso coletado
        } else if (recursos[i].offscreen()) {
            recursos.splice(i, 1); // Remove o recurso que saiu da tela
        }
    }

    // Atualiza e mostra obstáculos
    for (let i = obstaculos.length - 1; i >= 0; i--) {
        obstaculos[i].mover();
        obstaculos[i].mostrar();
        if (obstaculos[i].colisao(trator)) {
            vidas--;
            obstaculos.splice(i, 1); // Remove o obstáculo após a colisão
            if (vidas <= 0) {
                estadoJogo = 'fim';
            }
        } else if (obstaculos[i].offscreen()) {
            obstaculos.splice(i, 1); // Remove o obstáculo que saiu da tela
        }
    }

    // Mostra pontuação e vidas
    fill(255);
    textSize(18);
    text("Pontuação: " + pontuacao, 10, 20);
    text("Vidas: " + vidas, 10, 40);
}

function mostrarTelaFim() {
    textAlign(CENTER);
    textSize(40);
    fill(255, 0, 0);
    text("GAME OVER", width / 2, height / 2 - 50);
    fill(255);
    textSize(25);
    text("Sua pontuação final: " + pontuacao, width / 2, height / 2);
    textSize(20);
    text("Pressione R para reiniciar", width / 2, height / 2 + 50);
}

function keyPressed() {
    if (estadoJogo === 'inicio' && keyCode === ENTER) {
        estadoJogo = 'jogando';
    } else if (estadoJogo === 'fim' && keyCode === 82) { // 'R' key
        reiniciarJogo();
    }
}

function reiniciarJogo() {
    pontuacao = 0;
    vidas = 3;
    recursos = [];
    obstaculos = [];
    trator = new Trator();
    estadoJogo = 'jogando';
}

// --- Classes para os elementos do jogo ---

class Trator {
    constructor() {
        this.x = width / 2;
        this.y = height - 50;
        this.largura = 50;
        this.altura = 50;
        this.velocidade = 5;
    }

    mostrar() {
        fill(0, 150, 0); // Verde para o trator
        // Se você tiver uma imagem de trator:
        // image(imgTrator, this.x - this.largura / 2, this.y - this.altura / 2, this.largura, this.altura);
        rect(this.x - this.largura / 2, this.y - this.altura / 2, this.largura, this.altura);
    }

    mover() {
        if (keyIsDown(LEFT_ARROW)) {
            this.x -= this.velocidade;
        }
        if (keyIsDown(RIGHT_ARROW)) {
            this.x += this.velocidade;
        }
        // Limita o trator à tela
        this.x = constrain(this.x, this.largura / 2, width - this.largura / 2);
    }
}

class ObjetoCaindo { // Classe base para recursos e obstáculos
    constructor(x, y, largura, altura, velocidade) {
        this.x = x;
        this.y = y;
        this.largura = largura;
        this.altura = altura;
        this.velocidade = velocidade;
    }

    mover() {
        this.y += this.velocidade;
    }

    offscreen() {
        return this.y > height + this.altura;
    }

    colisao(outroObjeto) {
        let d = dist(this.x, this.y, outroObjeto.x, outroObjeto.y);
        return d < (this.largura / 2 + outroObjeto.largura / 2); // Colisão baseada em círculos
        // Ou colisão baseada em retângulos:
        /*
        return (this.x - this.largura / 2 < outroObjeto.x + outroObjeto.largura / 2 &&
                this.x + this.largura / 2 > outroObjeto.x - outroObjeto.largura / 2 &&
                this.y - this.altura / 2 < outroObjeto.y + outroObjeto.altura / 2 &&
                this.y + this.altura / 2 > outroObjeto.y - outroObjeto.altura / 2);
        */
    }
}

class Recurso extends ObjetoCaindo {
    constructor() {
        let x = random(width);
        let y = -20; // Começa acima da tela
        let largura = 30;
        let altura = 30;
        let velocidade = random(1, 3);
        super(x, y, largura, altura, velocidade);
        this.tipo = floor(random(2)); // 0 para milho, 1 para vaca (exemplo)
    }

    mostrar() {
        if (this.tipo === 0) {
            fill(255, 200, 0); // Amarelo para milho
            // Se você tiver imagem de milho:
            // image(imgMilho, this.x - this.largura / 2, this.y - this.altura / 2, this.largura, this.altura);
            ellipse(this.x, this.y, this.largura, this.altura);
        } else {
            fill(150, 75, 0); // Marrom para vaca (ou outro animal)
            // Se você tiver imagem de vaca:
            // image(imgVaca, this.x - this.largura / 2, this.y - this.altura / 2, this.largura, this.altura);
            rect(this.x - this.largura / 2, this.y - this.altura / 2, this.largura, this.altura);
        }
    }
}

class Obstaculo extends ObjetoCaindo {
    constructor() {
        let x = random(width);
        let y = -20;
        let largura = 40;
        let altura = 40;
        let velocidade = random(2, 5); // Obstáculos caem mais rápido
        super(x, y, largura, altura, velocidade);
    }

    mostrar() {
        fill(100); // Cinza para meteoros/pedras
        // Se você tiver imagem de meteoro:
        // image(imgMeteoro, this.x - this.largura / 2, this.y - this.altura / 2, this.largura, this.altura);
        ellipse(this.x, this.y, this.largura, this.altura);
    }
}